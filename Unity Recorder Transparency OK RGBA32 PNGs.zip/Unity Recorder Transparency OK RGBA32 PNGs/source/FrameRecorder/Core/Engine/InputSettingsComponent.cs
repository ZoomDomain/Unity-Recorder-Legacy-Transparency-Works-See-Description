﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnityEngine.Recorder
{
    public class InputSettingsComponent : MonoBehaviour
    {
        public List<RecorderInputSetting> m_Settings;
    }
}
    